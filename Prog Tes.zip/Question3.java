int n = array.length;
boolean swapped;
        for (int i = 0; i < n - 1; i++) {
swapped = false;

        for (int j = 0; j < n - i - 1; j++) {
        // Compare the adjacent elements
        if (array[j] > array[j + 1]) {
// Swap if they are in the wrong order
int temp = array[j];
array[j] = array[j + 1];
array[j + 1] = temp;

swapped = true;

// Print the array state after each comparison
        System.out.println("Step " + (i * (n - 1) + j + 1) + ":");