// Initialize the array to be sorted
int[] array = {20, 5, 15, 10, 3, 17, 7};

        System.out.println("Original array:");
printArray(array);

// Perform insertion sort
insertionSort(array);

        System.out.println("\nSorted array:");
printArray(array);

public static void insertionSort(int[] array) 
    int n = array.length;

    // Traverse through 1 to n-1 (since the element at index 0 is considered sorted)
    for (int i = 1; i < n; i++) {
        int key = array[i];
        int j = i - 1;

        // Move elements of array[0..i-1] that are greater than key to one position ahead
        // of their current position
        while (j >= 0 && array[j] > key)
            array[j + 1] = array[j];
            j--;
        }
        array[j + 1] = key;

        // Print the array after each insertion
        System.out.println("Step " + i + ":");
        printArray(array);

// Utility method to print the array
public static void printArray(int[] array)
    for (int value : array) {
        System.out.print(value + " ");